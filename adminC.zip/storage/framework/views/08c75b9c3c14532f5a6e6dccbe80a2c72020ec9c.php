<?php
use Illuminate\Support\Facades\Redirect;

?>

<?php $__env->startSection('contenido'); ?>
    <div class="row">
        <div class="col-lg-6 col-md-6 col-sm-6 col-sx-12">
            <h3>Editar empleado:<?php echo e($empleado->Nombre); ?> </h3>
            <?php if(count($errors)>0): ?>
            <div class="alert alert-danger">
                <ul>
                    <?php foreach($errors->all() as $err): ?>
                        <li><?php echo e($err); ?></li>
                    <?php endforeach; ?>
                </ul>

            </div>
            <?php endif; ?>
            
            <?php echo Form::model($empleado,['method'=>'PATCH','route'=>['administracion.empleado.update',$empleado->idEmpleados]]); ?>

            
            <?php echo e(Form::token()); ?>


             <div class="form-group">
                <label for="nombre"> Nombre </label>
                <input type="text" name="nombre" value="<?php echo e($empleado->nombre); ?>"  class="form-control" placeholder="Nombre ...">       
            </div>
            <div class="form-group">
                <label for="apellido"> Apellido </label>
                <input type="text" name="apellido" value="<?php echo e($empleado->apellido); ?>" class="form-control" placeholder="apellido ...">       
            </div>
            <div class="form-group">
                <label for="domicilio"> Domicilio </label>
                <input type="text" name="domicilio" value="<?php echo e($empleado->domicilio); ?>" class="form-control" placeholder="Domicilio ...">       
            </div>
            <div class="form-group">
                <label for="telefono"> Telefono </label>
                <input type="text" name="telefono" value="<?php echo e($empleado->telefono); ?>" class="form-control" placeholder="Telefono ...">       
            </div>
            <div class="form-group">
                <label for="celular"> Celular </label>
                <input type="text" name="celular" value="<?php echo e($empleado->celular); ?>" class="form-control" placeholder="Celular ...">       
            </div>
            <div class="form-group">
                <label for="fechaNacimiento"> Fecha  de Nacimiento </label>
                    <input type="text" name="fechaNacimiento" value="<?php echo e(DateTime::createFromFormat('Y-m-d', $empleado->fechaNacimiento)->format('d-m-Y')); ?>" class="form-control" placeholder="Fecha de Antiguedad ...">     

            </div>
            <div class="form-group">
                <label for="fechaAntiguedad"> Fecha de Antiguedad </label>
                <input type="text" name="fechaAntiguedad" value="<?php echo e(DateTime::createFromFormat('Y-m-d', $empleado->fechaAntiguedad)->format('d-m-Y')); ?>" class="form-control" placeholder="Fecha de Antiguedad ...">       
            </div>
            <div class="form-group">
                <label for="turno"> Turno </label>
                <select name="idturno" id="idturno" class="form-control">                
                    <?php if($empleado->turno===1): ?>
                    <option value="1" selected="selected"  >Mañana</option>  
                    <option value="2"  >Noche</option>    
                    <?php else: ?>
                    <option value="1"   >Mañana</option>  
                    <option value="2" selected="selected" >Noche</option>    
                    <?php endif; ?>
                    
                </select>   
            </div>
              <div class="form-group">
                <label for="usuario"> Usuario </label>
                <input type="text" name="usuario" value="<?php echo e($empleado->usuario); ?>" class="form-control" placeholder="Usuario ...">       
            </div>
              <div class="form-group">
                <label for="contraseña"> Contraseña </label>
                <input type="text" name="contraseña" value="<?php echo e($empleado->contraseña); ?>" class="form-control" placeholder="Contraseña ...">       
            <div class="form-group">
                <label for="contraseña">Tipo</label>
                <select name="idtipo" id="idtipo" class="form-control">  
                <?php foreach($tipos as $tip): ?>
                    <?php if($tip->idTipos === $empleado->Tipos_idTipos): ?>
                        <option value="<?php echo e($tip->idTipos); ?>" selected="selected"><?php echo e($tip->Nombre); ?></option>
                    <?php else: ?>
                        <option value="<?php echo e($tip->idTipos); ?>" ><?php echo e($tip->Nombre); ?></option>           
                    <?php endif; ?>
                <?php endforeach; ?>
                
                
                </select>
            </div>
         
            <div class="form-group">
                <button class = "btn btn-primary" type="submit"> Guardar</button>
                <a href='<?php echo e(URL::previous()); ?>' /><button class = "btn btn-default" > Cancelar</button> </a>
                
                
            </div>
          <script>
            $(document).ready(function(){
            $.fn.datepicker.defaults.language = 'es';
            });
            $(document).ready(function(){
                var date_input=$('input[name="fechaAntiguedad"]'); //our date input has the name "date"
                var container=$('.bootstrap-iso form').length>0 ? $('.bootstrap-iso form').parent() : "body";
                    date_input.datepicker({
                        format: 'dd-mm-yyyy',
                        container: container,
                        todayHighlight: true,
                        autoclose: true,
                    })
              
            var date_input=$('input[name="fechaNacimiento"]'); //our date input has the name "date"
                var container=$('.bootstrap-iso form').length>0 ? $('.bootstrap-iso form').parent() : "body";
                    date_input.datepicker({
                        format: 'dd-mm-yyyy',
                        container: container,
                        todayHighlight: true,
                        autoclose: true,
                        lenguage:'es'
                    })
                })
            </script>
            <?php echo Form::close(); ?>

            
        </div>
    </div>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.admin', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>