<?php
use Illuminate\Support\Facades\Redirect;
?>

<?php $__env->startSection('contenido'); ?>
    <div class="row">
        <div class="col-lg-6 col-md-6 col-sm-6 col-sx-12">
            <h3>Empleado <?php echo e($empleado->apellido); ?> <?php echo e($empleado->nombre); ?>  </h3>
           
            
           
            
         

             <div class="form-group">
                <label for="nombre"> Nombre: </label>
                <label ><?php echo e($empleado->nombre); ?></label>    
            </div>
            <div class="form-group">
                <label for="apellido"> Apellido: </label>
               <label ><?php echo e($empleado->apellido); ?></label>        
            </div>
            <div class="form-group">
                <label for="domicilio"> Domicilio: </label>
                <label ><?php echo e($empleado->domicilio); ?></label>  
            </div>
            <div class="form-group">
                <label for="telefono"> Telefono: </label>
                <label ><?php echo e($empleado->telefono); ?></label>        
            </div>
            <div class="form-group">
                <label for="celular"> Celular: </label>
                <label ><?php echo e($empleado->celular); ?></label>     
            </div>
            <div class="form-group">
                <label for="fechaNacimiento"> Fecha  de Nacimiento: </label>
                <label ><?php echo e(DateTime::createFromFormat('Y-m-d', $empleado->fechaNacimiento)->format('d-m-Y')); ?></label>  
            </div>
            <div class="form-group">
                <label for="fechaAntiguedad"> Fecha de Antiguedad: </label>
                <label ><?php echo e(DateTime::createFromFormat('Y-m-d', $empleado->fechaAntiguedad)->format('d-m-Y')); ?></label>  
            </div>
            <div class="form-group">
                <label for="turno"> Turno: </label>
                <label >
                <?php if($empleado->turno===1): ?>
                    Mañana
                <?php else: ?>
                    Noche
                <?php endif; ?>
                </label>  
            </div>
              <div class="form-group">
                <label for="usuario"> Usuario: </label>
                <label ><?php echo e($empleado->usuario); ?></label>     
            </div>
              <div class="form-group">
                <label for="contraseña"> Contraseña: </label>
                <label ><?php echo e($empleado->contraseña); ?></label>  
            </div>
              <div class="form-group">
                <label for="Tipos_idTurnos">Tipo: </label>                  
                <label >
                    <?php foreach($tipos as $tip): ?>
                    <?php if($tip->idTipos===$empleado->Tipos_idTipos): ?>
                        <?php echo e($tip->Nombre); ?>

                    <?php endif; ?>
                    <?php endforeach; ?>
                </label>  
            </div>
         
            <div class="form-group">
               
               <a href='<?php echo e(URL::previous()); ?>' ><button  class = "btn btn-default" > Atras</button></a>
                
                
            </div>
         
          
            
        </div>
    </div>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.admin', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>