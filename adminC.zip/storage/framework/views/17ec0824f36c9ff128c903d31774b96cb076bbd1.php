<?php $__env->startSection('contenido'); ?>
    <div class="row">
        <div class="col-lg-6 col-md-6 col-sm-6 col-sx-12">
            <h3 id="titulo">Crear Designaciones</h3>
            <div id="errors"></div>
            <?php if(count($errors)>0): ?>
            <div class="alert alert-danger">
                <ul>
                    <li value='a'></li>
                    <?php foreach($errors->all() as $err): ?>
                        <li><?php echo e($err); ?></li>
                    <?php endforeach; ?>
                </ul>

            </div>
            <?php endif; ?>
            <?php echo Form::model('designacion',['method'=>'POST','onsubmit'=>'return(validate());','action' => array('CronogramaController@storeDesignacion', $cartelera->idCarteleras, $cronograma->fecha)]); ?>

          
            <?php echo e(Form::token()); ?>

             <div class="form-group">
                <label for="descripcion">Fecha</label>
                <input class="form-control" name="fecha" id="fecha"  value="<?php echo e($cronograma->fecha); ?>" >   
            </div>
            <div class="form-group">
                <label for="cartelera">Cartelera</label>               
                <input class="form-control" name="cartelera" id="cartelera"  value="<?php echo e($cartelera->descripcion); ?>" disabled>                              
            </div>
            <div class="form-group">
                <label for="cartelera">Cant. Personas</label>               
                <input class="form-control" name="cantidadPersonas" id="cantidadPersonas"  value="<?php echo e($cartelera->cantidadPersonas); ?>" disabled>     
            </div>
            <?php ($NoContinuar = false); ?>
            <?php for($count=1;$count<$cartelera->cantidadPersonas/800;$count++): ?>
              
            <div class="form-group">                
            <label for="colectivo">Colectivo <?php echo e($count); ?></label>
                <select name="colectivo[]" id="colectivo[]" class="form-control">
                <?php if(count($colectivo)<$count): ?>
                 <option disabled selected value> No hay suficientes colectivos </option>
                 <?php ($NoContinuar = true); ?>
                <?php else: ?>
                    <?php ($c=0); ?>    
                    <?php foreach($colectivo as $cole): ?>
                    <?php ($c++); ?>    
                        <?php if($c===$count): ?>
                        <option value="<?php echo e($cole->idColectivos); ?>" selected="selected"><?php echo e($cole->matricula); ?></option>
                        <?php else: ?>
                            <option value="<?php echo e($cole->idColectivos); ?>" ><?php echo e($cole->matricula); ?></option>
                        <?php endif; ?>                      
                    <?php endforeach; ?>
                <?php endif; ?>
                </select>
            </div>
            
            <div class="form-group">
                <label for="chofer1">Chofer 1er Turno</label>               
                <select name="chofer1[]" id="chofer1[]" class="form-control" >
                <?php if(count($choferesT1)<$count): ?>
                 <option disabled selected value> No hay suficientes choferes del 1er turno </option>
                 <?php ($NoContinuar = true); ?>
                <?php else: ?>
                    <?php ($c1=0); ?>   
                    <?php foreach($choferesT1 as $chof1): ?>
                        <?php ($c1++); ?>
                        <?php if($c1===$count): ?>
                        <option value="<?php echo e($chof1->idEmpleados); ?>" selected="selected" ><?php echo e($chof1->nombre); ?> <?php echo e($chof1->apellido); ?></option>
                        <?php else: ?>
                            <option value="<?php echo e($chof1->idEmpleados); ?>"  ><?php echo e($chof1->nombre); ?> <?php echo e($chof1->apellido); ?></option>
                        <?php endif; ?>
                    <?php endforeach; ?>
                <?php endif; ?>
                 
                </select>
            </div>
            <div class="form-group">
                <label for="cartelera">Chofer 2er Turno</label>               
                <select name="chofer2[]" id="chofer2[]" class="form-control"> 
                <?php if(count($choferesT2)<$count): ?>
                 <option disabled selected value> No hay suficientes choferes del 2do turno </option>
                 <?php ($NoContinuar = true); ?>  
                <?php else: ?>
                    <?php ($c2=0); ?> 
                    <?php foreach($choferesT2 as $chof2): ?>
                    <?php ($c2++); ?>
                        <?php if($c2===$count): ?>
                        <option value="<?php echo e($chof2->idEmpleados); ?>" selected="selected" ><?php echo e($chof2->nombre); ?> <?php echo e($chof2->apellido); ?></option>
                        <?php else: ?>
                        <option value="<?php echo e($chof2->idEmpleados); ?>" ><?php echo e($chof2->nombre); ?> <?php echo e($chof2->apellido); ?></option>
                        <?php endif; ?>
                    <?php endforeach; ?>
                <?php endif; ?>
                 
                </select>
            </div>
         

            <?php endfor; ?>
         

            <div class="form-group">
             
               
                <?php if(!$NoContinuar): ?>
                <button class = "btn btn-primary" type="submit"> Guardar</button>
                <?php echo Form::close(); ?>

                 <a href="cronograma"><button class="btn btn-danger">Cancelar</button></a>
                <?php else: ?>                
                 <?php echo Form::close(); ?>

                 <a href="cronograma"><button class="btn btn-danger">Cancelar</button></a>
                <font color="red">No hay suficientes recursos para este cronograma</font>               
                <?php endif; ?>
                               
                
                
            </div>
             
           
             
            
        </div>
    </div>
<script>

//This will execute when the user presses the submit button.
/*
function validate() {
  //Loop through all form elements.
  var open= '<div class="alert alert-danger"><ul><li>Valores duplicados en';
  var close='</li></ul></div>';
  
        var chofer1 = document.forms[0].elements["chofer1[]"];
        var chofer2 = document.forms[0].elements["chofer2[]"]; 
        var colectivo = document.forms[0].elements["colectivo[]"];  
        var ch1=new Array(),ch2=new Array(),col = new Array();
        for (var i = 0, len = chofer1.length; i < len; i++) {
        ch1[i]=chofer1[i].value;
        ch2[i]=chofer2[i].value;
        col[i]=colectivo[i].value;
        }             
        
         $('#errors').empty();
        if((new Set(ch1)).size !== ch1.length){     
            $('#errors').append(open+' chofer 1er turno'+close);            
            return false; 
        }
        if((new Set(ch2)).size !== ch2.length){
              $('#errors').append(open+' chofer 2do turno'+close);            
              return false; 
        }
        if((new Set(col)).size !== col.length){
              $('#errors').append(open+' colectivos'+close);
              return false; 
            
        }
       
      return true; 
      
  }


</script>
<?php $__env->stopSection(); ?>


<?php echo $__env->make('layouts.admin', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>