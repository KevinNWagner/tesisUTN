<?php $__env->startSection('contenido'); ?>
    <div class="row">
        <div class="col-lg-12 col-md-12 col-sm-12 col-xs-12">
            <h3>Listado de Colectivos <a href="colectivo/create"><button class="btn btn-success">Nuevo</button></a></h3>
            <?php echo $__env->make('administracion.colectivo.search', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>            
        </div>
    </div>
    <div class="row">
        <div class="col-lg-12 col-md-12 col-sm-12 col-xs-12">
            <div class="table-responsive">
			<table class="table table-striped table-bordered table-condensed table-hover">
                <thead>
                    <th>ID</th>
                    <th>Marca</th>
                    <th>Modelo</th>
                    <th>Matricula</th>
                    <th>Ubicacion</th>
                    <th>Opciones</th>
                </thead>
                <?php foreach($colectivos as $tip): ?>
                <tr>
                    <td><?php echo e($tip->idColectivos); ?></td>
                    <td><?php echo e($tip->marca); ?></td>
                    <td><?php echo e($tip->modelo); ?></td>
                    <td><?php echo e($tip->matricula); ?></td>
                    <td></td>
         
                    <td>
                        <a href="<?php echo e(URL::action('ColectivoController@edit',$tip->idColectivos)); ?>"><button class="btn btn-info">Editar</button></a>
                         <a href="" data-target="#modal-delete-<?php echo e($tip->idColectivos); ?>" data-toggle="modal"><button class="btn btn-danger">Eliminar</button></a>
                        

                        
                       
                    </td>
                </tr>
                  <?php echo $__env->make('administracion.colectivo.modal', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
                <?php endforeach; ?>
            </table>
            </div>
            <?php echo e($colectivos->render()); ?>

        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.admin', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>