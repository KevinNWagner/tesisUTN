<?php

namespace sisAdmin\Events;

abstract class Event
{
    //
}
