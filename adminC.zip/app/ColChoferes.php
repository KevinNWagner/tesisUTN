<?php

namespace sisAdmin;

use Illuminate\Database\Eloquent\Model;

class ColChoferes extends Model
{
    protected $fillable=[
        'colectivo',      
        'chofer1',
        'chofer2',
        
    ];
}
